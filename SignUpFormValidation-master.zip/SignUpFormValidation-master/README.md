# SignUpFormValidation
Small sample Android app that demonstrates sign up form field validation, using custom View classes and StateListDrawables.

![Usage gif of SignUpFormValidator](https://github.com/SammyO/SignUpFormValidation/blob/master/assets/1_UlYArYlKjjxzaUY__koHnw.gif "SignUpFormValidator in action")
